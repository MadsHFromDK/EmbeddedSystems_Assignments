

/**
 * main.c
 */

#include <stdint.h>
#include "emp_type.h"
#include "tm4c123gh6pm.h"
#include "systick_frt.h"
#include "FreeRTOS.h"
#include "task.h"
#include "status_led.h"
#include "tmodel.h"
#include "leds.h"
#include "adc.h"
#include "queue.h"
#include "semphr.h"
#include "file.h"
#include "lcd.h"
#include "UI_task.h"
#include "key.h"


#define USERTASK_STACK_SIZE configMINIMAL_STACK_SIZE
#define IDLE_PRIO 0
#define LOW_PRIO  1
#define MED_PRIO  2
#define HIGH_PRIO 3

#define idle_state   1
#define locked_elevator   2
#define unlocked_elevator   3
#define moving_elevator   4
#define broken_elevator  5


#define QUEUE_LEN   128

#define BUTTON_CHECK_INTERVAL_MS 50
#define REQUIRED_PRESS_TIME_MS 600

QueueHandle_t xQueue_keypad, xQueue_lcd;
SemaphoreHandle_t xSemaphore_keypad, xSemaphore_lcd, xSemaphore_scoff;

extern INT8U elevator_state;


static void setupHardware(void)
/*****************************************************************************
*   Input    :  -
*   Output   :  -
*   Function :
*****************************************************************************/
{
  // TODO: Put hardware configuration and initialisation in here

  // Warning: If you do not initialize the hardware clock, the timings will be inaccurate
  init_systick();
  status_led_init();
  init_adc();
  init_gpio();
  xQueue_lcd = xQueueCreate( QUEUE_LEN , sizeof( INT8U ));
  xQueue_keypad = xQueueCreate( QUEUE_LEN , sizeof( INT8U ));
  xSemaphore_lcd = xSemaphoreCreateMutex();
  xSemaphore_keypad = xSemaphoreCreateMutex();
}

char change_int_to_char(INT8U number){
    switch(number){
        case 0:
            return '0';
        case 1:
            return '1';
        case 2:
            return '2';
        case 3:
            return '3';
        case 4:
            return '4';
        case 5:
            return '5';
        case 6:
            return '6';
        case 7:
            return '7';
        case 8:
            return '8';
        case 9:
            return '9';
    }
}

INT8U button_pushed()
{
  return( !(GPIO_PORTF_DATA_R & 0x10) );
}


void switch_task(void *pvParameters){

INT16U long_press_check = 0;

    while(1){
        if(button_pushed()){
            long_press_check += BUTTON_CHECK_INTERVAL_MS;
            GPIO_PORTF_DATA_R |= 0x04;
            GPIO_PORTF_DATA_R &= ~(0x02);
            if(long_press_check >= REQUIRED_PRESS_TIME_MS){
               elevator_state = locked_elevator;
           }
        }
        else{
            long_press_check = 0;
            GPIO_PORTF_DATA_R &= ~(0x04);
            GPIO_PORTF_DATA_R |= 0x02;
        }

       vTaskDelay(pdMS_TO_TICKS(BUTTON_CHECK_INTERVAL_MS)); // Delay before checking again

    }
}

int main(void)
{
    setupHardware();

    xTaskCreate(status_led_task, "Status_led", USERTASK_STACK_SIZE, NULL, LOW_PRIO, NULL );
    xTaskCreate(lcd_task, "LCD", USERTASK_STACK_SIZE, NULL, LOW_PRIO, NULL);
    xTaskCreate(key_task, "KEYPAD",USERTASK_STACK_SIZE, NULL, LOW_PRIO, NULL);
    xTaskCreate(switch_task, "switch",USERTASK_STACK_SIZE, NULL, LOW_PRIO, NULL);
    xTaskCreate(UI_task, "UI",USERTASK_STACK_SIZE, NULL, LOW_PRIO, NULL);

    vTaskStartScheduler();

	return 0;
}
