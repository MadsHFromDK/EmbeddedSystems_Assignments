/*
 * UI_task.h
 *
 *  Created on: Apr 20, 2023
 *      Author: rasmu
 */

#ifndef UI_TASK_H_
#define UI_TASK_H_

void UI_task(void *pvParameters);


#endif /* UI_TASK_H_ */
