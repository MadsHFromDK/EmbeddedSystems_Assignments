/*
 * UI_task.h
 *
 *  Created on: Apr 20, 2023
 *      Author: rasmu
 */

#ifndef UI_TASK_H_
#define UI_TASK_H_

char change_int_to_char1(INT8U number);

void UI_task(void *pvParameters);


#endif /* UI_TASK_H_ */
