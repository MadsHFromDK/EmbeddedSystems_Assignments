/**
 * main.c
 */

#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "emp_type.h"
#include "glob_def.h"
#include "systick_frt.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "tmodel.h"
#include "semphr.h"

#include "UI_task.h"
#include "key.h"
#include "leds.h"
#include "elevator.h"
#include "gpio.h"
#include "rotary_encoder.h"
#include "lcd.h"
#include "adc.h"

#define USERTASK_STACK_SIZE configMINIMAL_STACK_SIZE
#define IDLE_PRIO 0
#define LOW_PRIO  1
#define MED_PRIO  2
#define HIGH_PRIO 3

#define QUEUE_LEN   128

#define BUTTON_CHECK_INTERVAL_MS 50
#define REQUIRED_PRESS_TIME_MS 600

QueueHandle_t xQueue_keypad, xQueue_lcd;
SemaphoreHandle_t xSemaphore_keypad, xSemaphore_lcd, xSemaphore_scoff;

SemaphoreHandle_t xSemaphore_encoder;

static void setupHardware(void)
/*****************************************************************************
*   Input    :  -
*   Output   :  -
*   Function :
*****************************************************************************/
{

  // Warning: If you do not initialize the hardware clock, the timings will be inaccurate
  init_systick();
  init_gpio();
  init_adc();

  xQueue_lcd = xQueueCreate( QUEUE_LEN , sizeof( INT8U ));
  xQueue_keypad = xQueueCreate( QUEUE_LEN , sizeof( INT8U ));
  xSemaphore_lcd = xSemaphoreCreateMutex();
  xSemaphore_keypad = xSemaphoreCreateMutex();
}

INT8U button_pushed()
{
  return( !(GPIO_PORTF_DATA_R & 0x10) );
}

void switch_task(void *pvParameters){

INT16U long_press_check = 0;

    while(1){
        if(button_pushed()){
            long_press_check += BUTTON_CHECK_INTERVAL_MS;
            if(long_press_check >= REQUIRED_PRESS_TIME_MS){
                if(data.CUR_FLOOR == data.ELE_FLOOR){
                    elevator_state = LOCKED;
                }
                else{
                    data.FLOOR_SELECTION = data.CUR_FLOOR;
                    data.SELECTED = TRUE;
                    xQueueReset(xQueue_lcd);
                }
           }
        }
        else{
            long_press_check = 0;
        }

       vTaskDelay(pdMS_TO_TICKS(BUTTON_CHECK_INTERVAL_MS)); // Delay before checking again

    }
}

int main(void)
{
    setupHardware();

    xTaskCreate(elevator_task, "ELEVATOR", USERTASK_STACK_SIZE, NULL, LOW_PRIO, NULL);
    xTaskCreate(rotary_encoder_task, "Encoder_task", USERTASK_STACK_SIZE, NULL, LOW_PRIO, NULL);
    xTaskCreate(adc_task, "ADC", USERTASK_STACK_SIZE, NULL, LOW_PRIO, NULL);
    xTaskCreate(lcd_task, "LCD", USERTASK_STACK_SIZE, NULL, LOW_PRIO, NULL);
    xTaskCreate(key_task, "KEYPAD",USERTASK_STACK_SIZE, NULL, LOW_PRIO, NULL);
    xTaskCreate(led_task, "LED", USERTASK_STACK_SIZE, NULL, LOW_PRIO, NULL);
    xTaskCreate(switch_task, "LONGPRESS", USERTASK_STACK_SIZE, NULL, LOW_PRIO, NULL);
    xTaskCreate(UI_task, "UI",USERTASK_STACK_SIZE, NULL, LOW_PRIO, NULL);

    vTaskStartScheduler();
    return 0;
}
