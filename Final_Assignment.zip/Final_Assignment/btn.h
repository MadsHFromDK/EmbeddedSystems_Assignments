/*
 * btn.h
 *
 *  Created on: 13 May 2025
 *      Author: madsa
 */

INT8U button_pushed(void);

void switch_task(void *pvParameters);


