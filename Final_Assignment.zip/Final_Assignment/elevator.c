/*
 * elevator.c
 *
 *  Created on: 9 May 2025
 *      Author: madsa
 */

#include <stdint.h>
#include <stdlib.h>
#include "tm4c123gh6pm.h"
#include "FreeRTOS.h"
#include "Task.h"
#include "queue.h"
#include "semphr.h"
#include "emp_type.h"
#include "glob_def.h"

#include "elevator.h"
#include "lcd.h"
#include "rotary_encoder.h"

extern struct elevator_data data;
extern QueueHandle_t xQueue_lcd;
extern INT8S encoder_cnt;

LED_states led_state;
elevator_states elevator_state;

void init_elevator_state( void ){
    elevator_state = AWAY;
}

void elevator_task(void *pvParamters){

    FP32 vel = 0.5, acc = 0.5, acc_flr;
    static INT8U ele_flr, trgt_flr;
    static BOOLEAN start = FALSE, dir_up;

    init_elevator_state();

    while(1){
        if(elevator_state == AVAILABLE || elevator_state == AWAY){
            if(data.SELECTED == TRUE && !start){

                start = TRUE;
                ele_flr = data.ELE_FLOOR;
                trgt_flr = data.FLOOR_SELECTION;

                if(trgt_flr > ele_flr){
                    dir_up = TRUE;
                    acc_flr = ele_flr + (trgt_flr - ele_flr)/2;
                }
                else{
                    dir_up = FALSE;
                    acc_flr = trgt_flr + (ele_flr - trgt_flr)/2;
                }
            }
            else if(data.SELECTED == TRUE && start){

                if(dir_up == TRUE){
                    if(/*ele_flr == acc_flr || */ele_flr < acc_flr){
                        if(vel < 2){
                            vel += acc;
                        }

                        ele_flr += vel;
                        led_state = YELLOW;
                    }
                    else{
                        if(vel > 1){
                            vel -= acc;
                        }

                        ele_flr += vel;
                        led_state = RED;
                    }

                    if(ele_flr >= trgt_flr){
                        vel = 0.5;

                        data.NUM_TRIPS++;
                        data.SELECTED = FALSE;
                        data.CUR_FLOOR = data.FLOOR_SELECTION;
                        data.ELE_FLOOR = ele_flr;
                        start = FALSE;
                        led_state = GREEN;

                        if(data.NUM_TRIPS == 4){
                            encoder_cnt = 0;
                            led_state = FLASHING;
                            elevator_state = REPAIR;
                        }
                        else if(data.CUR_FLOOR == data.ELE_FLOOR){
                            elevator_state = LOCKED;
                        }
                    }
                }
                else{
                    if(/*ele_flr == acc_flr || */ele_flr > acc_flr){
                        if(vel < 2){
                            vel += acc;
                        }

                        ele_flr -= vel;
                        led_state = YELLOW;
                    }
                    else{
                        if(vel > 1){
                            vel -= acc;
                        }

                        ele_flr -= vel;
                        led_state = RED;
                    }

                    if(ele_flr <= trgt_flr){
                        vel = 0.5;

                        data.NUM_TRIPS++;
                        data.SELECTED = FALSE;
                        data.ELE_FLOOR = ele_flr;
                        data.CUR_FLOOR = data.FLOOR_SELECTION;
                        start = FALSE;
                        led_state = GREEN;

                        if(data.NUM_TRIPS == 4){
                            encoder_cnt = 0;
                            led_state = FLASHING;
                            elevator_state = REPAIR;
                        }
                        else if(data.CUR_FLOOR == data.ELE_FLOOR){
                            elevator_state = LOCKED;
                        }
                    }
                }

                vTaskDelay( 1000 / portTICK_RATE_MS);
            }
        }
        vTaskDelay(100 / portTICK_RATE_MS);
    }
}

