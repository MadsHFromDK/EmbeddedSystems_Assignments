/*
 * elevator.c
 *
 *  Created on: 9 May 2025
 *      Author: madsa
 */

#include <stdint.h>
#include <stdlib.h>
#include "tm4c123gh6pm.h"
#include "FreeRTOS.h"
#include "Task.h"
#include "queue.h"
#include "semphr.h"
#include "emp_type.h"
#include "glob_def.h"

#include "elevator.h"
#include "lcd.h"
#include "rotary_encoder.h"
#include "adc.h"

extern struct elevator_data data;
extern struct adc_data data_adc;
extern QueueHandle_t xQueue_lcd;
extern INT8S encoder_cnt;

LED_states led_state;
elevator_states elevator_state;

void init_elevator_state( void ){
    elevator_state = AWAY;
}

void elevator_task(void *pvParamters){

    init_elevator_state();

    FP32 vel = 1.0, acc = 0.5, acc_flr;
    static INT8U ele_flr, trgt_flr;
    static BOOLEAN start = FALSE, dir_up;
    INT8U digit1;
    INT8U digit2;
    char char_digit1;
    char char_digit2;

    while(1){
        if(elevator_state == AVAILABLE || elevator_state == AWAY || elevator_state == MOVING){
            if(data.SELECTED == TRUE && !start){
                start = TRUE;
                ele_flr = data.ELE_FLOOR;
                trgt_flr = data.FLOOR_SELECTION;
                elevator_state = MOVING;

                if(trgt_flr > ele_flr){
                    dir_up = TRUE;
                    if((trgt_flr + 1) != ele_flr){
                        acc_flr = ele_flr + (trgt_flr - ele_flr)/2;
                    }
                    else{
                        acc_flr = ele_flr;
                    }
                }
                else{
                    dir_up = FALSE;
                    if((trgt_flr -1) != ele_flr){
                        acc_flr = trgt_flr + (ele_flr - trgt_flr)/2;
                    }
                    else{
                        acc_flr = ele_flr;
                    }
                }
            }
            else if(data.SELECTED == TRUE && start && elevator_state == MOVING){

                if(dir_up == TRUE){
                    if(ele_flr < acc_flr){

                        if(vel < 3){
                            vel += acc;
                        }

                        ele_flr += vel;
                        led_state = YELLOW;
                    }
                    else{

                        if(vel > 1){
                            vel -= acc;
                        }

                        ele_flr += vel;
                        led_state = RED;
                    }

                    move_LCD(0,1);

                    INT8U digit1 = ele_flr/10;
                    INT8U digit2 = ele_flr%10;

                    char char_digit1 = change_int_to_char(digit1);
                    char char_digit2 = change_int_to_char(digit2);

                    xQueueSend( xQueue_lcd, &char_digit1, portMAX_DELAY );
                    xQueueSend( xQueue_lcd, &char_digit2, portMAX_DELAY );

                    move_LCD(8,1);

                    xQueueSend( xQueue_lcd, "v", portMAX_DELAY );
                    xQueueSend( xQueue_lcd, "e", portMAX_DELAY );
                    xQueueSend( xQueue_lcd, "l", portMAX_DELAY );
                    xQueueSend( xQueue_lcd, ":", portMAX_DELAY );
                    xQueueSend( xQueue_lcd, " ", portMAX_DELAY );

                    digit1 = vel;
                    digit2 = (INT8U)(vel*10)%10;

                    char_digit1 = change_int_to_char(digit1);
                    char_digit2 = change_int_to_char(digit2);

                    xQueueSend( xQueue_lcd, &char_digit1, portMAX_DELAY );
                    xQueueSend( xQueue_lcd, &char_digit2, portMAX_DELAY );


                    if(ele_flr >= trgt_flr){
                        vel = 1;

                        data.NUM_TRIPS++;
                        data.SELECTED = FALSE;
                        data.CUR_FLOOR = data.FLOOR_SELECTION;
                        data.ELE_FLOOR = ele_flr;
                        start = FALSE;
                        led_state = GREEN;

                        if(data.CUR_FLOOR == 20){
                            elevator_state = HOME;
                        }
                        else if(data.NUM_TRIPS == 4){
                            encoder_cnt = 0;
                            led_state = FLASHING;
                            elevator_state = REPAIR;

                            INT16U val = data_adc.val;

                            if(val < 200){
                                data_adc.trgt_val = rand()%(val*2);
                            }
                            else if (val >200 && val < 400){
                                data_adc.trgt_val = rand()%(val/2);
                            }
                        }
                        else if(data.CUR_FLOOR == data.ELE_FLOOR){
                            elevator_state = LOCKED;
                        }
                    }
                }
                else{
                    if(ele_flr > acc_flr){

                        if(vel < 3){
                            vel += acc;
                        }

                        ele_flr -= vel;
                        led_state = YELLOW;
                    }
                    else{

                        if(vel > 1){
                            vel -= acc;
                        }

                        ele_flr -= vel;
                        led_state = RED;
                    }

                    move_LCD(0,1);

                    digit1 = ele_flr/10;
                    digit2 = ele_flr%10;

                    char_digit1 = change_int_to_char(digit1);
                    char_digit2 = change_int_to_char(digit2);

                    xQueueSend( xQueue_lcd, &char_digit1, portMAX_DELAY );
                    xQueueSend( xQueue_lcd, &char_digit2, portMAX_DELAY );

                    move_LCD(8,1);

                    xQueueSend( xQueue_lcd, "v", portMAX_DELAY );
                    xQueueSend( xQueue_lcd, "e", portMAX_DELAY );
                    xQueueSend( xQueue_lcd, "l", portMAX_DELAY );
                    xQueueSend( xQueue_lcd, ":", portMAX_DELAY );
                    xQueueSend( xQueue_lcd, " ", portMAX_DELAY );

                    digit1 = vel;
                    digit2 = (INT8U)(vel*10)%10;

                    char_digit1 = change_int_to_char(digit1);
                    char_digit2 = change_int_to_char(digit2);

                    xQueueSend( xQueue_lcd, &char_digit1, portMAX_DELAY );
                    xQueueSend( xQueue_lcd, &char_digit2, portMAX_DELAY );


                    if(ele_flr <= trgt_flr){
                        vel = 1;

                        data.NUM_TRIPS++;
                        data.SELECTED = FALSE;
                        data.ELE_FLOOR = ele_flr;
                        data.CUR_FLOOR = data.FLOOR_SELECTION;
                        start = FALSE;
                        led_state = GREEN;

                        if(data.CUR_FLOOR == 20){
                            elevator_state = HOME;
                        }
                        else if(data.NUM_TRIPS == 4){
                            encoder_cnt = 0;
                            led_state = FLASHING;
                            elevator_state = REPAIR;

                            INT16U val = data_adc.val;

                            if(val < 200){
                                data_adc.trgt_val = rand()%(val*2);
                            }
                            else if (val >200 && val < 400){
                                data_adc.trgt_val = rand()%(val/2);
                            }
                        }
                        else if(data.CUR_FLOOR == data.ELE_FLOOR){
                            elevator_state = LOCKED;
                        }
                    }
                }

                vTaskDelay( 1000 / portTICK_RATE_MS);
            }
        }
        vTaskDelay(100 / portTICK_RATE_MS);
    }
}

