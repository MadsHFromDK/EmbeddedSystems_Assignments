#include <stdint.h>
#include <stdlib.h>
#include "tm4c123gh6pm.h"
#include "emp_type.h"
#include "lcd.h"
#include "glob_def.h"
#include "tmodel.h"
#include "FreeRTOS.h"
#include "Task.h"
#include "queue.h"
#include "semphr.h"
#include "glob_def.h"

#include "rotary_encoder.h"
#include "elevator.h"

extern QueueHandle_t xQueue_encoder, xQueue_lcd;
extern SemaphoreHandle_t xSemaphore_encoder, xSemaphore_lcd;
extern elevator_states elevator_state;
extern LED_states led_state;

encoder_state state;
INT8S encoder_cnt = 0;

struct elevator_data data;

//BOOLEAN detect_encoder_btn()
/*****************************************************************************
*   Input    :  -
*   Output   :  -
*   Function :  Detects button press on the encoder push-button
*****************************************************************************/

char change_int_to_char(INT8U number){
    switch(number){
        case 0:
            return '0';
        case 1:
            return '1';
        case 2:
            return '2';
        case 3:
            return '3';
        case 4:
            return '4';
        case 5:
            return '5';
        case 6:
            return '6';
        case 7:
            return '7';
        case 8:
            return '8';
        case 9:
            return '9';
    }
}

void init_strct(void){
    data.NUM_TRIPS = 0;
    data.CUR_FLOOR = 0;
    data.ELE_FLOOR = 2;
    data.SELECTED = FALSE;
    data.FLOOR_SELECTION = 0;
    data.REP_DIR = RIGHT;
}

void handle_encoder(void){
    INT8U pressed = !(GPIO_PORTA_DATA_R & 0x80);
    static INT8U btn_pressed = FALSE;

    if(elevator_state == AVAILABLE){

        if(pressed && btn_pressed == FALSE && encoder_cnt != 13){
            data.FLOOR_SELECTION = encoder_cnt;
            data.SELECTED = TRUE;

            btn_pressed = TRUE;
        }
        else if(!(pressed) && (btn_pressed == TRUE)){
            btn_pressed = FALSE;
        }

    }
    else if(elevator_state == REPAIR){

        if(pressed && btn_pressed == FALSE){

            if(data.REP_DIR == RIGHT){

                if(encoder_cnt >= REPAIR_VAL){  //Fixed

                    led_state = GREEN;

                    data.NUM_TRIPS = 0;
                    data.REP_DIR = LEFT;
                    elevator_state = LOCKED;
                    encoder_cnt = data.CUR_FLOOR;
                }

            }
            else{
                if(encoder_cnt <= -(INT8S)REPAIR_VAL){          //Fixed
                    led_state = GREEN;

                    data.NUM_TRIPS = 0;
                    data.REP_DIR = RIGHT;
                    elevator_state = LOCKED;
                    encoder_cnt = data.CUR_FLOOR;
                }
            }

            btn_pressed = TRUE;
        }
        else if(!(pressed) && (btn_pressed == TRUE)){
            btn_pressed = FALSE;
        }
    }
}

void rotary_encoder_task(void *pvParameters){
    static INT8U prev_AB = 0;      // Previous state of Phase A and Phase B

    init_strct();

    while(1){

        // Read the current state of PA5 (Phase A) and PA6 (Phase B)
        INT8U A_in = (GPIO_PORTA_DATA_R & 0x20) ? 1 : 0;        // Read PA5
        INT8U B_in = (GPIO_PORTA_DATA_R & 0x40) ? 1 : 0;        // Read PA6

        // Combine Phase A and Phase B into a single value
        INT8U current_AB = (A_in << 1) | B_in;

        // Decode the quadrature signals
        if (current_AB != prev_AB || !(GPIO_PORTA_DATA_R & 0x80)) { // Only process if there is a change
            INT8U transition = current_AB ^ prev_AB;

            if (A_in == B_in){ // Same state for Phase A and Phase B
                if (transition == 0b10){
                    data.dir = LEFT;
                    encoder_cnt--;
                } else if (transition == 0b01){
                    data.dir = RIGHT;
                    encoder_cnt++;
                }
            }
            else { // Different state for Phase A and Phase B
                if (transition == 0b10) {
                    data.dir = LEFT;
                } else if (transition == 0b01) {
                    data.dir = RIGHT;
                }
            }

            if(elevator_state != REPAIR){
                if(encoder_cnt > ENCODER_MAX_VAL){
                    encoder_cnt = ENCODER_MAX_VAL;
                }
                else if(encoder_cnt < 0){
                    encoder_cnt = 0;
                }
            }

            // Update the previous AB value
            prev_AB = current_AB;

            handle_encoder();
        }

        vTaskDelay(1 / portTICK_RATE_MS);  // 1 ms delay
    }
}
