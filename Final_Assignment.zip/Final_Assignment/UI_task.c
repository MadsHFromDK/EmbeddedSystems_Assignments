/*****************************************************************************
* University of Southern Denmark
* Embedded C Programming (ECP)
*
* MODULENAME.: leds.c
*
* PROJECT....: ECP
*
* DESCRIPTION: See module specification file (.h-file).
*
* Change Log:
******************************************************************************
* Date    Id    Change
* YYMMDD
* --------------------
* 050128  KA    Module created.
*
*****************************************************************************/

/***************************** Include files *******************************/
#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "emp_type.h"
#include "FreeRTOS.h"
#include "Task.h"
#include "queue.h"
#include "semphr.h"
#include "glob_def.h"
#include "elevator.h"
#include "UI_task.h"
#include "adc.h"
#include "key.h"
#include "lcd.h"
#include "elevator.h"
#include "rotary_encoder.h"


/*****************************    Defines    *******************************/
#define PF0     0       // Bit 0
#define idle_state   1
#define locked_elevator   2
#define unlocked_elevator  3
#define moving_elevator   4
#define broken_elevator  5

/*****************************   Constants   *******************************/

/*INT16U min_in 0;
INT16U max_in 4095;
INT16U min_out 100;
INT16U max_out 1000; */

/*****************************   Variables   *******************************/

extern QueueHandle_t xQueue_keypad, xQueue_lcd;
extern SemaphoreHandle_t xSemaphore_keypad, xSemaphore_lcd, xSemaphore_scoff;
extern elevator_states elevator_state;
extern INT8S encoder_cnt;
extern struct elevator_data data;

/*****************************   Functions   *******************************/

char change_int_to_char1(INT8U number){
    switch(number){
        case 0:
            return '0';
        case 1:
            return '1';
        case 2:
            return '2';
        case 3:
            return '3';
        case 4:
            return '4';
        case 5:
            return '5';
        case 6:
            return '6';
        case 7:
            return '7';
        case 8:
            return '8';
        case 9:
            return '9';
    }
    return '0';
}

void string_to_LCD(INT8U text_length, char text[]) {
    INT8U text_count = 0;
    char send_lcd;
        while (text_count < text_length) {
            send_lcd = text[text_count];
            xQueueSend(xQueue_lcd, &send_lcd, portMAX_DELAY);
            text_count++;
        }
}

INT8U convert_string_to_int(char *input, INT8U length){
    INT8U result = 0;
    INT8U i = 0;

    while (i < length) {
        if (input[i] >= '0' && input[i] <= '9') {  // Ensure it's a valid digit
            result = result * 10 + (input[i] - '0');  // Convert char to integer
        }
        i++;
    }
    return result;
}

void UI_task(void *pvParameters){

char idle_text[] = "Call elevator";
INT8U idle_text_length = 13;
char locked_text[] = "Enter password: ";
INT8U locked_text_length = 17;
char unlocked_text[] = "Choose floor: ";
INT8U unlocked_text_length = 13;
char repair_enc_text[] = "Fix - Encoder";
INT8U repair_enc_text_length = 13;

INT8U key_press;
INT8U key_temp;
INT8U key_count = 0;
INT8U code_length = 4;
char key_code[] = "xxxx";
char key_code_prev[] = "qqqq";
INT8U key_code_int;

INT8U digit1;
INT8U digit2;
char char_digit1;
char char_digit2;
char right_text[] = "Right: ";
char left_text[] = "Left: ";

INT8U prev_state = 0;
INT8U reset_lcd = 0xFF;

    while(1){
        switch(elevator_state){
        case LOCKED:
            if(prev_state != elevator_state){
                key_count = 0;
                key_code[0] = 'x';
                key_code[1] = 'x';
                key_code[2] = 'x';
                key_code[3] = 'x';
                xQueueReset(xQueue_lcd);
                xQueueSend( xQueue_lcd, &reset_lcd, portMAX_DELAY);
                prev_state = elevator_state;

                string_to_LCD(locked_text_length, locked_text);
                move_LCD(0,1);

                string_to_LCD(code_length, key_code);

                move_LCD(0,1);
            }

            if(uxQueueMessagesWaiting(xQueue_keypad))
                {
                if( xSemaphoreTake( xSemaphore_keypad, portMAX_DELAY))
                {
                    if( xQueueReceive( xQueue_keypad, &key_press, portMAX_DELAY ))
                    {
                        key_temp = key_press;
                        key_code[key_count] = change_int_to_char(key_temp);
                        key_count++;
                    }
                  }
                    xSemaphoreGive( xSemaphore_keypad );
                }
            vTaskDelay( 10 / portTICK_RATE_MS); // wait 100-1000 ms. (200-1000)

            if(key_code[0] != key_code_prev[0] || key_code[1] != key_code_prev[1] || key_code[2] != key_code_prev[2] || key_code[3] != key_code_prev[3]){
                string_to_LCD(code_length, key_code);
                move_LCD(0,1);
            }

            if(key_count == code_length){
                key_code_int = convert_string_to_int(&key_code, code_length);
                key_count = 0;
                if(key_code_int % 8 == 0){
                    elevator_state = AVAILABLE;
                }
                else{
                    elevator_state = LOCKED;
                }
            }

            key_code_prev[0] = key_code[0];
            key_code_prev[1] = key_code[1];
            key_code_prev[2] = key_code[2];
            key_code_prev[3] = key_code[3];

            //move_LCD(0,1);

            break;

            case AWAY:
                if(prev_state != elevator_state){
                    key_count = 0;
                    key_code[0] = 'x';
                    key_code[1] = 'x';
                    key_code[2] = 'x';
                    key_code[3] = 'x';
                    xQueueReset(xQueue_lcd);
                    xQueueSend( xQueue_lcd, &reset_lcd, portMAX_DELAY);
                    prev_state = elevator_state;

                    string_to_LCD(idle_text_length, idle_text);
                    move_LCD(0,0);
                }

            break;

            case AVAILABLE:
                if(prev_state != elevator_state){
                    key_count = 0;
                    key_code[0] = 'x';
                    key_code[1] = 'x';
                    key_code[2] = 'x';
                    key_code[3] = 'x';
                    xQueueReset(xQueue_lcd);
                    xQueueSend( xQueue_lcd, &reset_lcd, portMAX_DELAY);
                    prev_state = elevator_state;
                }

                string_to_LCD(unlocked_text_length, unlocked_text);
                move_LCD(0,1);

                digit1 = abs(encoder_cnt)/10;
                digit2 = abs(encoder_cnt)%10;

                char_digit1 = change_int_to_char(digit1);
                char_digit2 = change_int_to_char(digit2);

                move_LCD(0,1);

                xQueueSend( xQueue_lcd, &char_digit1, portMAX_DELAY );
                xQueueSend( xQueue_lcd, &char_digit2, portMAX_DELAY );

                move_LCD(0,0);
            break;

            case REPAIR:
                if(prev_state != elevator_state){
                    key_count = 0;
                    key_code[0] = 'x';
                    key_code[1] = 'x';
                    key_code[2] = 'x';
                    key_code[3] = 'x';
                    xQueueReset(xQueue_lcd);
                    xQueueSend( xQueue_lcd, &reset_lcd, portMAX_DELAY);
                    prev_state = elevator_state;
                }

                string_to_LCD(repair_enc_text_length, repair_enc_text);
                move_LCD(0,1);

                if(data.REP_DIR == RIGHT){
                    string_to_LCD(7, right_text);
                }
                else{
                    string_to_LCD(6, left_text);
                }

                digit1 = abs(encoder_cnt)/10;
                digit2 = abs(encoder_cnt)%10;

                char_digit1 = change_int_to_char(digit1);
                char_digit2 = change_int_to_char(digit2);

                xQueueSend( xQueue_lcd, &char_digit1, portMAX_DELAY );
                xQueueSend( xQueue_lcd, &char_digit2, portMAX_DELAY );

                move_LCD(0,0);

            break;

        }

    }

    }

