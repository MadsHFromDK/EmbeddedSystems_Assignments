/*
 * gpio.h
 *
 *  Created on: 5 May 2025
 *      Author: madsa
 */

#ifndef GPIO_H_
#define GPIO_H_

void init_rot_enc(void);

void init_gpio(void);

#endif /* GPIO_H_ */
